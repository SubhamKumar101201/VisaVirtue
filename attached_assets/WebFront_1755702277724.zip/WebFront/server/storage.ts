import { type User, type InsertUser, type Application, type InsertApplication, type Contact, type InsertContact, type VisaRequirement, type InsertVisaRequirement, type Destination, type InsertDestination } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createApplication(application: InsertApplication): Promise<Application>;
  getApplication(id: string): Promise<Application | undefined>;
  getApplicationByNumber(applicationNumber: string): Promise<Application | undefined>;
  updateApplicationStatus(id: string, status: string): Promise<Application | undefined>;
  getAllApplications(): Promise<Application[]>;
  
  createContact(contact: InsertContact): Promise<Contact>;
  getAllContacts(): Promise<Contact[]>;
  
  getVisaRequirement(fromCountry: string, toCountry: string, purpose: string): Promise<VisaRequirement | undefined>;
  getAllVisaRequirements(): Promise<VisaRequirement[]>;
  createVisaRequirement(requirement: InsertVisaRequirement): Promise<VisaRequirement>;
  
  getAllDestinations(): Promise<Destination[]>;
  getDestination(id: string): Promise<Destination | undefined>;
  createDestination(destination: InsertDestination): Promise<Destination>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private applications: Map<string, Application>;
  private contacts: Map<string, Contact>;
  private visaRequirements: Map<string, VisaRequirement>;
  private destinations: Map<string, Destination>;

  constructor() {
    this.users = new Map();
    this.applications = new Map();
    this.contacts = new Map();
    this.visaRequirements = new Map();
    this.destinations = new Map();
    
    // Initialize with sample destinations
    this.initializeDestinations();
    this.initializeVisaRequirements();
  }

  private generateApplicationNumber(): string {
    return `VV-${new Date().getFullYear()}-${Math.random().toString().substr(2, 6)}`;
  }

  private initializeDestinations() {
    const sampleDestinations: (InsertDestination & { id: string })[] = [
      {
        id: randomUUID(),
        name: "Dubai",
        country: "UAE",
        description: "Modern metropolis with stunning architecture and luxury shopping",
        imageUrl: "https://images.unsplash.com/photo-1518684079-3c830dcef090?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        visaRequired: "Yes",
        processingTime: "3-5 days",
        priceFrom: "$350",
        highlights: ["Burj Khalifa", "Dubai Mall", "Palm Jumeirah", "Desert Safari"],
        requirements: ["Valid passport", "Passport photo", "Travel insurance", "Bank statements"]
      },
      {
        id: randomUUID(),
        name: "London",
        country: "UK",
        description: "Historic city with rich culture and world-class attractions",
        imageUrl: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        visaRequired: "Varies",
        processingTime: "15-20 days",
        priceFrom: "$450",
        highlights: ["Big Ben", "British Museum", "Tower Bridge", "Buckingham Palace"],
        requirements: ["Valid passport", "Visa application form", "Financial proof", "Travel itinerary"]
      },
      {
        id: randomUUID(),
        name: "Singapore",
        country: "Singapore",
        description: "Modern city-state with diverse culture and cuisine",
        imageUrl: "https://images.unsplash.com/photo-1565967511849-76a60a516170?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        visaRequired: "No*",
        processingTime: "N/A",
        priceFrom: "Free**",
        highlights: ["Marina Bay Sands", "Gardens by the Bay", "Sentosa Island", "Chinatown"],
        requirements: ["Valid passport", "Return ticket", "Sufficient funds"]
      },
      {
        id: randomUUID(),
        name: "Tokyo",
        country: "Japan",
        description: "Vibrant metropolis blending tradition and technology",
        imageUrl: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        visaRequired: "Varies",
        processingTime: "5-10 days",
        priceFrom: "$280",
        highlights: ["Tokyo Tower", "Shibuya Crossing", "Mount Fuji", "Traditional Temples"],
        requirements: ["Valid passport", "Visa application", "Photo", "Financial documents"]
      }
    ];

    sampleDestinations.forEach(dest => {
      const destination: Destination = {
        ...dest,
        processingTime: dest.processingTime ?? null,
        priceFrom: dest.priceFrom ?? null,
      };
      this.destinations.set(dest.id, destination);
    });
  }

  private initializeVisaRequirements() {
    const sampleRequirements: (InsertVisaRequirement & { id: string })[] = [
      {
        id: randomUUID(),
        fromCountry: "United States",
        toCountry: "Dubai, UAE",
        purpose: "Tourism",
        required: true,
        processingTime: "3-5 business days",
        validity: "60 days",
        entryType: "Multiple Entry",
        fee: "$350",
        documents: ["Valid passport", "Passport photo", "Travel insurance", "Bank statements"]
      },
      {
        id: randomUUID(),
        fromCountry: "United Kingdom",
        toCountry: "Dubai, UAE",
        purpose: "Tourism",
        required: true,
        processingTime: "3-5 business days",
        validity: "60 days",
        entryType: "Multiple Entry",
        fee: "$350",
        documents: ["Valid passport", "Passport photo", "Travel insurance", "Bank statements"]
      },
      {
        id: randomUUID(),
        fromCountry: "India",
        toCountry: "France",
        purpose: "Tourism",
        required: true,
        processingTime: "15-20 business days",
        validity: "90 days",
        entryType: "Single/Multiple Entry",
        fee: "$95",
        documents: ["Valid passport", "Visa application form", "Recent passport photos", "Travel itinerary", "Hotel bookings", "Bank statements", "Travel insurance"]
      },
      {
        id: randomUUID(),
        fromCountry: "India",
        toCountry: "United States",
        purpose: "Tourism",
        required: true,
        processingTime: "3-5 weeks",
        validity: "10 years",
        entryType: "Multiple Entry",
        fee: "$185",
        documents: ["Valid passport", "DS-160 form", "Photo", "Interview appointment", "Bank statements", "Employment letter"]
      }
    ];

    sampleRequirements.forEach(req => {
      const key = `${req.fromCountry}-${req.toCountry}-${req.purpose}`;
      const requirement: VisaRequirement = {
        ...req,
        processingTime: req.processingTime ?? null,
        validity: req.validity ?? null,
        entryType: req.entryType ?? null,
        fee: req.fee ?? null,
        documents: req.documents || [],
      };
      this.visaRequirements.set(key, requirement);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = randomUUID();
    const applicationNumber = this.generateApplicationNumber();
    const application: Application = {
      ...insertApplication,
      id,
      applicationNumber,
      status: "submitted",
      createdAt: new Date(),
      updatedAt: new Date(),
      travelDate: insertApplication.travelDate ?? null,
      returnDate: insertApplication.returnDate ?? null,
      documents: insertApplication.documents || [],
    };
    this.applications.set(id, application);
    return application;
  }

  async getApplication(id: string): Promise<Application | undefined> {
    return this.applications.get(id);
  }

  async getApplicationByNumber(applicationNumber: string): Promise<Application | undefined> {
    return Array.from(this.applications.values()).find(
      (app) => app.applicationNumber === applicationNumber,
    );
  }

  async updateApplicationStatus(id: string, status: string): Promise<Application | undefined> {
    const application = this.applications.get(id);
    if (application) {
      const updated = { ...application, status, updatedAt: new Date() };
      this.applications.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async getAllApplications(): Promise<Application[]> {
    return Array.from(this.applications.values());
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = {
      ...insertContact,
      id,
      phone: insertContact.phone ?? null,
      service: insertContact.service ?? null,
      createdAt: new Date(),
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getAllContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }

  async getVisaRequirement(fromCountry: string, toCountry: string, purpose: string): Promise<VisaRequirement | undefined> {
    const key = `${fromCountry}-${toCountry}-${purpose}`;
    return this.visaRequirements.get(key);
  }

  async getAllVisaRequirements(): Promise<VisaRequirement[]> {
    return Array.from(this.visaRequirements.values());
  }

  async createVisaRequirement(insertRequirement: InsertVisaRequirement): Promise<VisaRequirement> {
    const id = randomUUID();
    const requirement: VisaRequirement = { 
      ...insertRequirement, 
      id,
      processingTime: insertRequirement.processingTime ?? null,
      validity: insertRequirement.validity ?? null,
      entryType: insertRequirement.entryType ?? null,
      fee: insertRequirement.fee ?? null,
      documents: insertRequirement.documents || [],
    };
    const key = `${requirement.fromCountry}-${requirement.toCountry}-${requirement.purpose}`;
    this.visaRequirements.set(key, requirement);
    return requirement;
  }

  async getAllDestinations(): Promise<Destination[]> {
    return Array.from(this.destinations.values());
  }

  async getDestination(id: string): Promise<Destination | undefined> {
    return this.destinations.get(id);
  }

  async createDestination(insertDestination: InsertDestination): Promise<Destination> {
    const id = randomUUID();
    const destination: Destination = { 
      ...insertDestination, 
      id,
      processingTime: insertDestination.processingTime ?? null,
      priceFrom: insertDestination.priceFrom ?? null,
      highlights: insertDestination.highlights || [],
      requirements: insertDestination.requirements || [],
    };
    this.destinations.set(id, destination);
    return destination;
  }
}

export const storage = new MemStorage();
