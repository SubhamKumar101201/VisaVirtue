import { Link } from "wouter";
import { Globe, Facebook, Twitter, Linkedin, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Footer() {
  return (
    <footer className="bg-visa-navy text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center mb-6">
              <Globe className="text-visa-gold text-3xl mr-3" size={32} />
              <div className="text-2xl font-bold">VisaVirtue</div>
            </div>
            <p className="text-blue-100 mb-6 leading-relaxed">
              Your trusted partner for international visa services. We simplify the visa application process with expert guidance, secure processing, and exceptional customer service.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="bg-blue-700 hover:bg-blue-600">
                <Facebook size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="bg-blue-700 hover:bg-blue-600">
                <Twitter size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="bg-blue-700 hover:bg-blue-600">
                <Linkedin size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="bg-blue-700 hover:bg-blue-600">
                <Instagram size={20} />
              </Button>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-bold text-lg mb-6">Services</h3>
            <ul className="space-y-3 text-blue-100">
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Tourist Visas</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Business Visas</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Student Visas</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Express Services</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Document Services</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Consultation</Link></li>
            </ul>
          </div>

          {/* Destinations */}
          <div>
            <h3 className="font-bold text-lg mb-6">Destinations</h3>
            <ul className="space-y-3 text-blue-100">
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Dubai, UAE</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">United States</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">United Kingdom</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Singapore</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Japan</Link></li>
              <li><Link href="/destinations" className="hover:text-visa-gold transition-colors">View All</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-bold text-lg mb-6">Support</h3>
            <ul className="space-y-3 text-blue-100">
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Help Center</Link></li>
              <li><Link href="/track-status" className="hover:text-visa-gold transition-colors">Track Application</Link></li>
              <li><Link href="/contact" className="hover:text-visa-gold transition-colors">Contact Us</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Live Chat</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">FAQ</Link></li>
              <li><Link href="#" className="hover:text-visa-gold transition-colors">Appointment</Link></li>
            </ul>
          </div>
        </div>

        {/* Newsletter Signup */}
        <div className="mt-12 pt-8 border-t border-blue-800">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="font-bold text-lg mb-2">Stay Updated</h3>
              <p className="text-blue-100">Get the latest visa updates, travel tips, and exclusive offers.</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 bg-white text-gray-900"
              />
              <Button className="bg-visa-gold text-visa-navy hover:bg-yellow-500 font-semibold">
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="mt-12 pt-8 border-t border-blue-800">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-blue-100 text-sm">
              © 2024 VisaVirtue. All rights reserved. | Licensed Visa Consultancy Services
            </div>
            <div className="flex space-x-6 text-sm">
              <Link href="#" className="text-blue-100 hover:text-visa-gold transition-colors">Privacy Policy</Link>
              <Link href="#" className="text-blue-100 hover:text-visa-gold transition-colors">Terms of Service</Link>
              <Link href="#" className="text-blue-100 hover:text-visa-gold transition-colors">Cookie Policy</Link>
              <Link href="#" className="text-blue-100 hover:text-visa-gold transition-colors">Refund Policy</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
