const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    // MongoDB connection string - using Replit's environment
    const mongoURI = process.env.DATABASE_URL || 'mongodb://localhost:27017/visavirtue';
    
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log('MongoDB connected successfully');
  } catch (error) {
    console.error('MongoDB connection error:', error);
    process.exit(1);
  }
};

module.exports = connectDB;