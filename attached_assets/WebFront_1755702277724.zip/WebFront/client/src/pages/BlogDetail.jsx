import React from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, User, Clock, ArrowLeft, Share, BookOpen } from 'lucide-react';

const BlogDetail = () => {
  const { slug } = useParams();

  // This would normally fetch the blog post based on slug
  const post = {
    title: 'Complete Guide to US Tourist Visa Application 2024',
    content: `
      <p>Planning a trip to the United States? Understanding the B-2 tourist visa application process is crucial for a successful journey. This comprehensive guide will walk you through everything you need to know about applying for a US tourist visa in 2024.</p>
      
      <h2>What is a B-2 Tourist Visa?</h2>
      <p>The B-2 tourist visa is a non-immigrant visa that allows foreign nationals to visit the United States temporarily for leisure, tourism, or medical treatment. This visa is perfect for those planning to visit family, explore American attractions, or receive medical care.</p>
      
      <h2>Key Requirements</h2>
      <p>To qualify for a B-2 tourist visa, you must demonstrate:</p>
      <ul>
        <li>Strong ties to your home country</li>
        <li>Sufficient funds to support your trip</li>
        <li>Intent to return home after your visit</li>
        <li>No criminal background</li>
      </ul>
      
      <h2>Required Documents</h2>
      <p>Gather these essential documents before your application:</p>
      <ol>
        <li>Valid passport with at least 6 months remaining validity</li>
        <li>Completed DS-160 form</li>
        <li>Visa application fee payment receipt</li>
        <li>Passport-style photograph</li>
        <li>Supporting documents (bank statements, employment letter, etc.)</li>
      </ol>
      
      <h2>Application Process</h2>
      <p>The US tourist visa application process involves several steps:</p>
      <ol>
        <li><strong>Complete the DS-160 form online</strong> - This is your official visa application</li>
        <li><strong>Pay the visa application fee</strong> - Currently $160 for most applicants</li>
        <li><strong>Schedule your interview</strong> - Most applicants between 14-79 years old must attend an interview</li>
        <li><strong>Attend the visa interview</strong> - Be prepared to answer questions about your trip</li>
        <li><strong>Wait for processing</strong> - Processing times vary by embassy/consulate</li>
      </ol>
      
      <h2>Interview Tips</h2>
      <p>Your visa interview is crucial. Here are some tips for success:</p>
      <ul>
        <li>Arrive early and dress professionally</li>
        <li>Bring all required documents</li>
        <li>Answer questions honestly and concisely</li>
        <li>Demonstrate strong ties to your home country</li>
        <li>Show proof of sufficient funds</li>
      </ul>
      
      <h2>Common Reasons for Rejection</h2>
      <p>Understanding why applications get rejected can help you avoid common pitfalls:</p>
      <ul>
        <li>Insufficient ties to home country</li>
        <li>Inadequate financial resources</li>
        <li>Previous immigration violations</li>
        <li>Incomplete or inaccurate application</li>
        <li>Inability to demonstrate intent to return</li>
      </ul>
      
      <h2>Processing Times and Fees</h2>
      <p>Processing times vary by location and season. Generally:</p>
      <ul>
        <li>Interview scheduling: 1-4 weeks</li>
        <li>Administrative processing: 2-12 weeks</li>
        <li>Visa fee: $160 (non-refundable)</li>
        <li>Validity: Up to 10 years (multiple entries)</li>
      </ul>
      
      <h2>Final Thoughts</h2>
      <p>Applying for a US tourist visa requires careful preparation and attention to detail. While the process can seem daunting, following these guidelines will significantly improve your chances of approval. Remember, honesty and proper documentation are key to a successful application.</p>
      
      <p>If you need assistance with your US tourist visa application, our expert team at VisaVirtue is here to help. Contact us today for personalized guidance and support throughout your visa journey.</p>
    `,
    author: 'Sarah Johnson',
    date: '2024-02-15',
    category: 'Visa Tips',
    readTime: 8,
    image: 'https://images.unsplash.com/photo-1569098644584-210bcd375b59?w=1200&h=600&fit=crop',
    tags: ['US Visa', 'Tourist Visa', 'B-2 Visa', 'Travel', 'Immigration']
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Header */}
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            onClick={() => window.history.back()}
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-500 mb-6"
          >
            <ArrowLeft size={20} />
            <span>Back to Blog</span>
          </motion.button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <div className="flex items-center space-x-3 mb-4">
              <span className="px-3 py-1 bg-blue-100 text-blue-600 text-sm font-medium rounded-full">
                {post.category}
              </span>
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <div className="flex items-center space-x-1">
                  <User size={16} />
                  <span>{post.author}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar size={16} />
                  <span>{new Date(post.date).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock size={16} />
                  <span>{post.readTime} min read</span>
                </div>
              </div>
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
              {post.title}
            </h1>

            {/* Share buttons */}
            <div className="flex items-center space-x-4">
              <span className="text-gray-600">Share:</span>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Share size={16} />
                <span>Share</span>
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Image */}
      <motion.section
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="py-8"
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-96 object-cover rounded-2xl shadow-lg"
          />
        </div>
      </motion.section>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
          {/* Main Content */}
          <motion.article
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="lg:col-span-3"
          >
            <div className="bg-white rounded-xl shadow-md p-8">
              <div 
                className="prose prose-lg max-w-none"
                dangerouslySetInnerHTML={{ __html: post.content }}
                style={{
                  lineHeight: '1.8',
                  fontSize: '18px',
                  color: '#374151'
                }}
              />

              {/* Tags */}
              <div className="mt-8 pt-8 border-t border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {post.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-gray-100 text-gray-600 text-sm rounded-full hover:bg-blue-100 hover:text-blue-600 transition-colors cursor-pointer"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Author Info */}
              <div className="mt-8 pt-8 border-t border-gray-200">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full flex items-center justify-center">
                    <User size={24} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{post.author}</h3>
                    <p className="text-gray-600">Senior Visa Consultant</p>
                    <p className="text-sm text-gray-500 mt-1">
                      Sarah has over 8 years of experience helping clients navigate visa applications 
                      for the United States and other countries.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.article>

          {/* Sidebar */}
          <motion.aside
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="lg:col-span-1 space-y-8"
          >
            {/* Table of Contents */}
            <div className="bg-white rounded-xl shadow-md p-6 sticky top-24">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <BookOpen className="w-5 h-5 mr-2" />
                Table of Contents
              </h3>
              <nav className="space-y-3">
                <a href="#what-is-b2" className="block text-sm text-gray-600 hover:text-blue-600 transition-colors">
                  What is a B-2 Tourist Visa?
                </a>
                <a href="#requirements" className="block text-sm text-gray-600 hover:text-blue-600 transition-colors">
                  Key Requirements
                </a>
                <a href="#documents" className="block text-sm text-gray-600 hover:text-blue-600 transition-colors">
                  Required Documents
                </a>
                <a href="#process" className="block text-sm text-gray-600 hover:text-blue-600 transition-colors">
                  Application Process
                </a>
                <a href="#interview" className="block text-sm text-gray-600 hover:text-blue-600 transition-colors">
                  Interview Tips
                </a>
                <a href="#rejection" className="block text-sm text-gray-600 hover:text-blue-600 transition-colors">
                  Common Reasons for Rejection
                </a>
                <a href="#processing" className="block text-sm text-gray-600 hover:text-blue-600 transition-colors">
                  Processing Times and Fees
                </a>
              </nav>
            </div>

            {/* Related Articles */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Related Articles</h3>
              <div className="space-y-4">
                {[
                  'UK Visa Changes: What You Need to Know in 2024',
                  'Schengen Visa Application Guide',
                  'Business Visa vs Work Permit Differences'
                ].map((title, index) => (
                  <div key={index} className="border-b border-gray-100 pb-3 last:border-0">
                    <h4 className="text-sm font-medium text-gray-900 hover:text-blue-600 cursor-pointer transition-colors">
                      {title}
                    </h4>
                    <p className="text-xs text-gray-500 mt-1">5 min read</p>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl text-white p-6">
              <h3 className="text-lg font-semibold mb-3">Need Help with Your Visa?</h3>
              <p className="text-blue-100 text-sm mb-4">
                Our expert team can guide you through the entire visa application process.
              </p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full py-3 bg-white text-blue-600 rounded-lg font-medium hover:bg-gray-100 transition-colors"
              >
                Get Expert Help
              </motion.button>
            </div>
          </motion.aside>
        </div>
      </div>
    </div>
  );
};

export default BlogDetail;