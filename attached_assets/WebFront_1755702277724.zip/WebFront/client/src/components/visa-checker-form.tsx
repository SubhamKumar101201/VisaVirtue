import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CheckCircle, Clock, FileText, DollarSign } from "lucide-react";
import {
  countries,
  purposeOptions,
  durationOptions,
} from "@/lib/destinations-data";
import type { VisaRequirement } from "@shared/schema";

export function VisaCheckerForm() {
  const [formData, setFormData] = useState({
    fromCountry: "",
    toCountry: "",
    purpose: "",
    duration: "",
  });
  const [showResults, setShowResults] = useState(false);

  const { data: visaRequirement, isLoading } = useQuery<VisaRequirement>({
    queryKey: [
      "/api/visa-requirements",
      formData.fromCountry,
      formData.toCountry,
      formData.purpose,
    ],
    queryFn: async () => {
      const params = new URLSearchParams({
        fromCountry: formData.fromCountry,
        toCountry: formData.toCountry,
        purpose: formData.purpose,
      });
      const response = await fetch(`/api/visa-requirements?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch visa requirement");
      }
      return response.json();
    },
    enabled:
      showResults &&
      Boolean(formData.fromCountry && formData.toCountry && formData.purpose),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.fromCountry && formData.toCountry && formData.purpose) {
      setShowResults(true);
    }
  };

  const updateFormData = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setShowResults(false);
  };

  return (
    <section className="py-20 bg-gradient-to-br from-visa-navy to-blue-800">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Visa Requirement Checker
          </h2>
          <p className="text-blue-100 text-lg">
            Check visa requirements between any two countries instantly
          </p>
        </div>

        <Card className="shadow-2xl">
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">
                    From Country
                  </label>
                  <Select
                    value={formData.fromCountry}
                    onValueChange={(value) =>
                      updateFormData("fromCountry", value)
                    }
                  >
                    <SelectTrigger className="w-full p-4 border border-gray-300 rounded-lg">
                      <SelectValue placeholder="Select your country" />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((country) => (
                        <SelectItem key={country} value={country}>
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-gray-700 font-semibold mb-2">
                    To Country
                  </label>
                  <Select
                    value={formData.toCountry}
                    onValueChange={(value) =>
                      updateFormData("toCountry", value)
                    }
                  >
                    <SelectTrigger className="w-full p-4 border border-gray-300 rounded-lg">
                      <SelectValue placeholder="Select destination" />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((country) => (
                        <SelectItem key={country} value={country}>
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">
                    Purpose of Visit
                  </label>
                  <Select
                    value={formData.purpose}
                    onValueChange={(value) => updateFormData("purpose", value)}
                  >
                    <SelectTrigger className="w-full p-4 border border-gray-300 rounded-lg">
                      <SelectValue placeholder="Select purpose" />
                    </SelectTrigger>
                    <SelectContent>
                      {purposeOptions.map((purpose) => (
                        <SelectItem key={purpose} value={purpose}>
                          {purpose}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-gray-700 font-semibold mb-2">
                    Duration of Stay
                  </label>
                  <Select
                    value={formData.duration}
                    onValueChange={(value) => updateFormData("duration", value)}
                  >
                    <SelectTrigger className="w-full p-4 border border-gray-300 rounded-lg">
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      {durationOptions.map((duration) => (
                        <SelectItem key={duration} value={duration}>
                          {duration}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="text-center">
                <Button
                  type="submit"
                  className="bg-visa-gold text-visa-navy px-8 py-4 text-lg font-semibold"
                  disabled={
                    !formData.fromCountry ||
                    !formData.toCountry ||
                    !formData.purpose ||
                    isLoading
                  }
                >
                  {isLoading ? "Checking..." : "Check Requirements"}
                </Button>
              </div>
            </form>

            {/* Results Section */}
            {showResults && (
              <div className="mt-8 p-6 bg-green-50 border border-green-200 rounded-lg">
                {visaRequirement ? (
                  <div className="flex items-start space-x-4">
                    <CheckCircle
                      className="text-green-600 text-2xl mt-1"
                      size={24}
                    />
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-green-800 mb-2">
                        {visaRequirement.required
                          ? "Visa Required"
                          : "No Visa Required"}
                      </h3>
                      <p className="text-green-700 mb-4">
                        {visaRequirement.required
                          ? `A ${formData.purpose.toLowerCase()} visa is required for ${formData.fromCountry} citizens traveling to ${formData.toCountry}.`
                          : `Citizens of ${formData.fromCountry} can travel to ${formData.toCountry} without a visa for ${formData.purpose.toLowerCase()} purposes.`}
                      </p>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center">
                            <Clock size={16} className="mr-1" />
                            Processing Time:
                          </span>
                          <span>{visaRequirement.processingTime || "N/A"}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="flex items-center">
                            <FileText size={16} className="mr-1" />
                            Validity:
                          </span>
                          <span>{visaRequirement.validity || "N/A"}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="flex items-center">
                            <FileText size={16} className="mr-1" />
                            Entry Type:
                          </span>
                          <span>{visaRequirement.entryType || "N/A"}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="flex items-center">
                            <DollarSign size={16} className="mr-1" />
                            Fee:
                          </span>
                          <span className="font-semibold">
                            {visaRequirement.fee || "Free"}
                          </span>
                        </div>
                      </div>

                      {visaRequirement.required && (
                        <Button className="mt-4 bg-visa-navy text-white hover:bg-blue-800">
                          Start Application
                        </Button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center">
                    <p className="text-gray-600">
                      No visa requirement information found for this
                      combination.
                    </p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
