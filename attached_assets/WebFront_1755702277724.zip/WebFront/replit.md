# VisaVirtue - Premium Visa Service Platform

## Overview

VisaVirtue is a comprehensive MERN stack visa service platform that provides complete visa assistance and immigration consulting services worldwide. The platform combines modern React frontend with Node.js/Express backend, featuring advanced authentication, real-time application tracking, blog system, and comprehensive service offerings.

The application serves as a complete business solution for visa services, including tourist visas, business visas, student visas, work permits, document services, and expert consultations. It targets both end users seeking visa services and provides administrative capabilities for service providers.

## Recent Changes (December 2024)

**Complete MERN Stack Transformation:**
- ✅ Rebuilt entire application using MERN architecture (MongoDB, Express.js, React, Node.js)
- ✅ Implemented comprehensive authentication system with JWT tokens and password security
- ✅ Created modern, responsive UI with React Router, Framer Motion animations, and AOS effects
- ✅ Built complete user dashboard with application tracking and profile management
- ✅ Added professional blog system with categories, search, and detailed article pages
- ✅ Implemented comprehensive service catalog with detailed service pages
- ✅ Created advanced visa requirements checker with real-time results
- ✅ Added contact system with consultation booking and support features
- ✅ Integrated modern components: Navbar with authentication state, Footer with social links
- ✅ Added protected routes system for user-specific functionality

**Key Features Delivered:**
- Authentication: Login/Signup with form validation and security features
- Dashboard: Personal dashboard with application stats and quick actions
- Services: Comprehensive service catalog with pricing and details
- Visa Checker: Interactive tool for checking visa requirements by country
- Blog: Professional blog system with categories and detailed articles
- Profile Management: Complete user profile with security settings
- Application Tracking: Advanced application management with status tracking
- Modern Design: Professional UI with animations, gradients, and responsive layout

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system (visa-navy, visa-gold themes)
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Real-time Updates**: Custom WebSocket hook for live application status updates

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with real-time WebSocket support
- **Real-time Communication**: WebSocket server for application status broadcasting
- **Data Storage**: In-memory storage (MemStorage) with PostgreSQL schema defined for production
- **Validation**: Zod schemas shared between frontend and backend
- **Build System**: esbuild for server-side bundling

### Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Management**: Shared schema definitions between client and server
- **Tables**: 
  - Users (authentication)
  - Applications (visa applications with status tracking)
  - Contacts (customer inquiries)
  - Visa Requirements (country-to-country visa rules)
  - Destinations (travel destination information)
- **Features**: UUID primary keys, timestamps, JSONB for document storage

### Authentication & Security
- Session-based authentication preparation (connect-pg-simple for session storage)
- CORS handling and request validation middleware
- Secure file upload handling for visa documents
- Input validation with Zod schemas

### Development Environment
- **Development Server**: Vite dev server with hot module replacement
- **Production Build**: Static file serving with Express
- **Database Migrations**: Drizzle Kit for schema management
- **Development Tools**: Replit integration with cartographer and error overlay plugins

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver for Neon database
- **drizzle-orm**: Type-safe ORM for database operations
- **drizzle-kit**: Database migration and schema management tool

### UI/UX Libraries
- **@radix-ui/***: Comprehensive set of unstyled, accessible UI primitives
- **@tanstack/react-query**: Powerful data synchronization for React
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe CSS class composition
- **cmdk**: Command menu component for search interfaces

### Form Handling
- **react-hook-form**: Performant forms library with minimal re-renders
- **@hookform/resolvers**: Validation resolvers for react-hook-form
- **zod**: TypeScript-first schema validation

### Real-time Communication
- **ws**: WebSocket library for real-time features
- **embla-carousel-react**: Touch-friendly carousel component

### Development Tools
- **vite**: Fast build tool with hot module replacement
- **@vitejs/plugin-react**: React support for Vite
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **@replit/vite-plugin-cartographer**: Replit-specific development features

### Utilities
- **date-fns**: Modern JavaScript date utility library
- **nanoid**: URL-safe unique string ID generator
- **clsx**: Utility for constructing className strings conditionally