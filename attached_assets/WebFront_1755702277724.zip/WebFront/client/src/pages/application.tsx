import { ApplicationWizard } from "@/components/application-wizard";

export default function Application() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="pt-20">
        <ApplicationWizard />
      </div>
    </div>
  );
}
