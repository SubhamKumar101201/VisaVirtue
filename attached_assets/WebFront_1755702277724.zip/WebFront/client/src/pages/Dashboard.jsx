import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  ArrowRight,
  TrendingUp,
  Users,
  Globe
} from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();

  // Mock data - replace with real API calls
  const stats = [
    { icon: FileText, label: 'Total Applications', value: '3', color: 'blue' },
    { icon: Clock, label: 'In Progress', value: '1', color: 'yellow' },
    { icon: CheckCircle, label: 'Approved', value: '2', color: 'green' },
    { icon: AlertCircle, label: 'Pending Review', value: '0', color: 'red' }
  ];

  const recentApplications = [
    {
      id: 'VV-2024-001',
      service: 'Tourist Visa',
      country: 'United Kingdom',
      status: 'approved',
      submittedDate: '2024-01-15',
      completedDate: '2024-01-28'
    },
    {
      id: 'VV-2024-002',
      service: 'Business Visa',
      country: 'Singapore',
      status: 'processing',
      submittedDate: '2024-02-01',
      estimatedCompletion: '2024-02-15'
    },
    {
      id: 'VV-2024-003',
      service: 'Student Visa',
      country: 'Canada',
      status: 'approved',
      submittedDate: '2024-01-20',
      completedDate: '2024-02-05'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'text-green-600 bg-green-100';
      case 'processing': return 'text-yellow-600 bg-yellow-100';
      case 'rejected': return 'text-red-600 bg-red-100';
      case 'submitted': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatColor = (color) => {
    switch (color) {
      case 'blue': return 'text-blue-600 bg-blue-100';
      case 'green': return 'text-green-600 bg-green-100';
      case 'yellow': return 'text-yellow-600 bg-yellow-100';
      case 'red': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
            Welcome back, {user?.firstName}!
          </h1>
          <p className="text-lg text-gray-600">
            Here's an overview of your visa applications and account activity.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Stats Cards */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-4"
            >
              {stats.map((stat, index) => (
                <div key={stat.label} className="bg-white rounded-xl shadow-md p-6">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getStatColor(stat.color)}`}>
                      <stat.icon size={24} />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <p className="text-sm text-gray-600">{stat.label}</p>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>

            {/* Recent Applications */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white rounded-xl shadow-md"
            >
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-gray-900">Recent Applications</h2>
                  <Link 
                    to="/applications"
                    className="text-blue-600 hover:text-blue-500 font-medium flex items-center space-x-1"
                  >
                    <span>View All</span>
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
              
              <div className="divide-y divide-gray-200">
                {recentApplications.map((application) => (
                  <div key={application.id} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-semibold text-gray-900">{application.service}</h3>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(application.status)}`}>
                            {application.status}
                          </span>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <div className="flex items-center space-x-1">
                            <Globe size={14} />
                            <span>{application.country}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <FileText size={14} />
                            <span>{application.id}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar size={14} />
                            <span>Submitted {new Date(application.submittedDate).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                      <button className="text-blue-600 hover:text-blue-500 font-medium">
                        View Details
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white rounded-xl shadow-md p-6"
            >
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Link to="/services">
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 cursor-pointer"
                  >
                    <FileText className="w-8 h-8 text-blue-600 mb-2" />
                    <h3 className="font-medium text-gray-900 mb-1">New Application</h3>
                    <p className="text-sm text-gray-600">Start a new visa application</p>
                  </motion.div>
                </Link>

                <Link to="/visa-checker">
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 cursor-pointer"
                  >
                    <Globe className="w-8 h-8 text-blue-600 mb-2" />
                    <h3 className="font-medium text-gray-900 mb-1">Check Requirements</h3>
                    <p className="text-sm text-gray-600">Verify visa requirements</p>
                  </motion.div>
                </Link>

                <Link to="/contact">
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 cursor-pointer"
                  >
                    <Users className="w-8 h-8 text-blue-600 mb-2" />
                    <h3 className="font-medium text-gray-900 mb-1">Get Support</h3>
                    <p className="text-sm text-gray-600">Contact our expert team</p>
                  </motion.div>
                </Link>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Profile Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white rounded-xl shadow-md p-6"
            >
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User size={32} className="text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">
                  {user?.firstName} {user?.lastName}
                </h3>
                <p className="text-sm text-gray-600">Member since January 2024</p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Mail size={16} className="text-gray-400" />
                  <span className="text-sm text-gray-600">{user?.email}</span>
                </div>
                {user?.phone && (
                  <div className="flex items-center space-x-3">
                    <Phone size={16} className="text-gray-400" />
                    <span className="text-sm text-gray-600">{user.phone}</span>
                  </div>
                )}
                {user?.country && (
                  <div className="flex items-center space-x-3">
                    <MapPin size={16} className="text-gray-400" />
                    <span className="text-sm text-gray-600">{user.country}</span>
                  </div>
                )}
              </div>

              <Link to="/profile">
                <button className="w-full mt-6 py-2 px-4 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors">
                  Edit Profile
                </button>
              </Link>
            </motion.div>

            {/* News & Updates */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white rounded-xl shadow-md p-6"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Latest Updates</h3>
              <div className="space-y-4">
                <div className="border-l-4 border-blue-600 pl-4">
                  <h4 className="font-medium text-gray-900 text-sm">New Express Service</h4>
                  <p className="text-xs text-gray-600 mt-1">
                    Get your visa processed in just 2-3 business days with our new express service.
                  </p>
                  <span className="text-xs text-gray-500">2 days ago</span>
                </div>
                
                <div className="border-l-4 border-green-600 pl-4">
                  <h4 className="font-medium text-gray-900 text-sm">UK Visa Updates</h4>
                  <p className="text-xs text-gray-600 mt-1">
                    New requirements for UK visitor visas effective March 2024.
                  </p>
                  <span className="text-xs text-gray-500">1 week ago</span>
                </div>
              </div>
              
              <Link to="/blog">
                <button className="w-full mt-4 py-2 px-4 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors text-sm">
                  View All Updates
                </button>
              </Link>
            </motion.div>

            {/* Support Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl text-white p-6"
            >
              <div className="text-center">
                <Users className="w-12 h-12 mx-auto mb-4 opacity-80" />
                <h3 className="text-lg font-semibold mb-2">Need Help?</h3>
                <p className="text-sm text-blue-100 mb-4">
                  Our expert team is here to assist you with any questions about your visa applications.
                </p>
                <Link to="/contact">
                  <button className="w-full py-2 px-4 bg-white text-blue-600 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                    Contact Support
                  </button>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;