import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertApplicationSchema, insertContactSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket & { applicationId?: string }) => {
    console.log('WebSocket client connected');

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        if (data.type === 'subscribe' && data.applicationId) {
          // Subscribe to application updates
          ws.applicationId = data.applicationId;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // Broadcast function for application updates
  function broadcastApplicationUpdate(applicationId: string, status: string) {
    wss.clients.forEach((client: WebSocket & { applicationId?: string }) => {
      if (client.readyState === WebSocket.OPEN && client.applicationId === applicationId) {
        client.send(JSON.stringify({
          type: 'statusUpdate',
          applicationId,
          status,
          timestamp: new Date().toISOString()
        }));
      }
    });
  }

  // Applications routes
  app.post("/api/applications", async (req, res) => {
    try {
      const validatedData = insertApplicationSchema.parse(req.body);
      const application = await storage.createApplication(validatedData);
      res.json(application);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid application data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/applications/:id", async (req, res) => {
    try {
      const application = await storage.getApplication(req.params.id);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      res.json(application);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/applications/number/:applicationNumber", async (req, res) => {
    try {
      const application = await storage.getApplicationByNumber(req.params.applicationNumber);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      res.json(application);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/applications/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const application = await storage.updateApplicationStatus(req.params.id, status);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Broadcast status update to WebSocket clients
      broadcastApplicationUpdate(req.params.id, status);
      
      res.json(application);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/applications", async (req, res) => {
    try {
      const applications = await storage.getAllApplications();
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Contacts routes
  app.post("/api/contacts", async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(validatedData);
      res.json(contact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid contact data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getAllContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Visa requirements routes
  app.get("/api/visa-requirements/:fromCountry/:toCountry/:purpose", async (req, res) => {
    try {
      const { fromCountry, toCountry, purpose } = req.params;
      console.log(`Looking for visa requirement: ${fromCountry} -> ${toCountry} (${purpose})`);
      const requirement = await storage.getVisaRequirement(fromCountry, toCountry, purpose);
      if (!requirement) {
        console.log(`No requirement found for key: ${fromCountry}-${toCountry}-${purpose}`);
        return res.status(404).json({ message: "Visa requirement not found" });
      }
      res.json(requirement);
    } catch (error) {
      console.error("Visa requirements route error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/visa-requirements", async (req, res) => {
    try {
      const { fromCountry, toCountry, purpose } = req.query;
      
      if (fromCountry && toCountry && purpose) {
        const requirement = await storage.getVisaRequirement(
          fromCountry as string,
          toCountry as string,
          purpose as string
        );
        if (!requirement) {
          return res.status(404).json({ message: "Visa requirement not found" });
        }
        res.json(requirement);
      } else {
        const requirements = await storage.getAllVisaRequirements();
        res.json(requirements);
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Destinations routes
  app.get("/api/destinations", async (req, res) => {
    try {
      const destinations = await storage.getAllDestinations();
      res.json(destinations);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/destinations/:id", async (req, res) => {
    try {
      const destination = await storage.getDestination(req.params.id);
      if (!destination) {
        return res.status(404).json({ message: "Destination not found" });
      }
      res.json(destination);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
