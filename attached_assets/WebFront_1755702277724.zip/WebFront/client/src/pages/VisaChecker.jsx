import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  MapPin, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Clock,
  FileText,
  DollarSign,
  Plane,
  Users
} from 'lucide-react';

const VisaChecker = () => {
  const [fromCountry, setFromCountry] = useState('');
  const [toCountry, setToCountry] = useState('');
  const [purpose, setPurpose] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  // Mock visa requirements data
  const visaRequirements = {
    'United States-United Kingdom-Tourism': {
      required: false,
      type: 'Visa Waiver Program (ESTA)',
      processingTime: '72 hours',
      validity: '90 days',
      cost: '$21',
      requirements: [
        'Valid passport with at least 6 months validity',
        'ESTA authorization',
        'Return or onward ticket',
        'Proof of sufficient funds',
        'No criminal record'
      ],
      notes: 'UK citizens can travel to the US for tourism or business for up to 90 days without a visa under the Visa Waiver Program.'
    },
    'India-United States-Tourism': {
      required: true,
      type: 'B-2 Tourist Visa',
      processingTime: '3-15 business days',
      validity: '10 years (multiple entry)',
      cost: '$160',
      requirements: [
        'Valid passport with at least 6 months validity',
        'Completed DS-160 form',
        'Visa appointment confirmation',
        'Visa fee payment receipt',
        'Photograph meeting US visa requirements',
        'Supporting documents (employment letter, bank statements, etc.)'
      ],
      notes: 'Indian citizens require a B-2 tourist visa to enter the United States for tourism purposes.'
    },
    'Canada-United Kingdom-Tourism': {
      required: false,
      type: 'No visa required',
      processingTime: 'At border',
      validity: '6 months',
      cost: 'Free',
      requirements: [
        'Valid Canadian passport',
        'Return or onward ticket',
        'Proof of sufficient funds for stay',
        'Accommodation details'
      ],
      notes: 'Canadian citizens can visit the UK for tourism for up to 6 months without a visa.'
    }
  };

  const countries = [
    'Afghanistan', 'Albania', 'Algeria', 'Argentina', 'Australia', 'Austria', 'Bangladesh', 
    'Belgium', 'Brazil', 'Canada', 'China', 'Denmark', 'Egypt', 'France', 'Germany', 
    'India', 'Indonesia', 'Italy', 'Japan', 'Malaysia', 'Netherlands', 'Pakistan', 
    'Philippines', 'Singapore', 'South Korea', 'Spain', 'Thailand', 'Turkey', 
    'United Kingdom', 'United States', 'Vietnam'
  ];

  const purposes = [
    'Tourism', 'Business', 'Study', 'Work', 'Medical', 'Transit'
  ];

  const handleSearch = async () => {
    if (!fromCountry || !toCountry || !purpose) {
      return;
    }

    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const key = `${fromCountry}-${toCountry}-${purpose}`;
    const requirement = visaRequirements[key] || {
      required: true,
      type: 'Visa Required',
      processingTime: '5-15 business days',
      validity: 'Varies',
      cost: 'Varies',
      requirements: [
        'Valid passport with at least 6 months validity',
        'Completed visa application form',
        'Recent passport-sized photographs',
        'Proof of travel arrangements',
        'Financial documentation',
        'Supporting documents based on purpose of visit'
      ],
      notes: `${fromCountry} citizens require a visa to visit ${toCountry} for ${purpose.toLowerCase()} purposes. Please check with the embassy for specific requirements.`
    };

    setResult(requirement);
    setLoading(false);
  };

  const getStatusIcon = () => {
    if (!result) return null;
    
    if (result.required) {
      return <XCircle className="w-8 h-8 text-red-500" />;
    } else {
      return <CheckCircle className="w-8 h-8 text-green-500" />;
    }
  };

  const getStatusColor = () => {
    if (!result) return '';
    return result.required ? 'border-red-200 bg-red-50' : 'border-green-200 bg-green-50';
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Visa Requirements Checker
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              Check visa requirements for your destination instantly. 
              Get accurate, up-to-date information for 195+ countries.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search Form */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-white rounded-2xl shadow-lg p-8 mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* From Country */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <MapPin className="inline w-4 h-4 mr-1" />
                From Country
              </label>
              <select
                value={fromCountry}
                onChange={(e) => setFromCountry(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              >
                <option value="">Select your country</option>
                {countries.map(country => (
                  <option key={country} value={country}>{country}</option>
                ))}
              </select>
            </div>

            {/* To Country */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Plane className="inline w-4 h-4 mr-1" />
                To Country
              </label>
              <select
                value={toCountry}
                onChange={(e) => setToCountry(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              >
                <option value="">Select destination</option>
                {countries.map(country => (
                  <option key={country} value={country}>{country}</option>
                ))}
              </select>
            </div>

            {/* Purpose */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Users className="inline w-4 h-4 mr-1" />
                Purpose of Visit
              </label>
              <select
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              >
                <option value="">Select purpose</option>
                {purposes.map(purpose => (
                  <option key={purpose} value={purpose}>{purpose}</option>
                ))}
              </select>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSearch}
            disabled={!fromCountry || !toCountry || !purpose || loading}
            className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
          >
            {loading ? (
              <>
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Checking Requirements...</span>
              </>
            ) : (
              <>
                <Search className="w-5 h-5" />
                <span>Check Visa Requirements</span>
              </>
            )}
          </motion.button>
        </motion.div>

        {/* Results */}
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className={`bg-white rounded-2xl shadow-lg border-2 ${getStatusColor()} overflow-hidden`}
          >
            {/* Result Header */}
            <div className="p-8 border-b border-gray-200">
              <div className="flex items-center space-x-4">
                {getStatusIcon()}
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">
                    {result.required ? 'Visa Required' : 'No Visa Required'}
                  </h2>
                  <p className="text-lg text-gray-600">
                    {fromCountry} → {toCountry} ({purpose})
                  </p>
                </div>
              </div>
            </div>

            <div className="p-8">
              {/* Quick Info */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-medium text-gray-900">Type</h3>
                  <p className="text-sm text-gray-600">{result.type}</p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <Clock className="w-6 h-6 text-yellow-600" />
                  </div>
                  <h3 className="font-medium text-gray-900">Processing Time</h3>
                  <p className="text-sm text-gray-600">{result.processingTime}</p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <Calendar className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="font-medium text-gray-900">Validity</h3>
                  <p className="text-sm text-gray-600">{result.validity}</p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <DollarSign className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="font-medium text-gray-900">Cost</h3>
                  <p className="text-sm text-gray-600">{result.cost}</p>
                </div>
              </div>

              {/* Requirements */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                  Required Documents
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {result.requirements.map((req, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      <span className="text-gray-700">{req}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Additional Notes */}
              <div className="bg-blue-50 rounded-lg p-6 mb-8">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-900 mb-1">Important Information</h4>
                    <p className="text-blue-800">{result.notes}</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-4">
                {result.required && (
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex-1 py-3 px-6 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                  >
                    Start Visa Application
                  </motion.button>
                )}
                
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 py-3 px-6 bg-white border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
                >
                  Get Expert Consultation
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="py-3 px-6 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                >
                  Save Results
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Popular Destinations */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mt-16"
        >
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Popular Destinations
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {['United States', 'United Kingdom', 'Canada', 'Australia', 'Germany', 'Japan', 'Singapore', 'UAE', 'France', 'Italy', 'Spain', 'Netherlands'].map((country, index) => (
              <motion.button
                key={country}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                whileHover={{ scale: 1.05 }}
                onClick={() => {
                  setToCountry(country);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-200 text-center"
              >
                <div className="w-12 h-8 bg-gray-200 rounded mx-auto mb-2"></div>
                <span className="text-sm font-medium text-gray-700">{country}</span>
              </motion.button>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default VisaChecker;