export const heroSlides = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    alt: "Dubai skyline",
    title: "Dubai",
    description: "Modern metropolis with luxury and innovation"
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1431274172761-fca41d930114?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    alt: "Paris Eiffel Tower",
    title: "Paris",
    description: "City of lights and romance"
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    alt: "New York City skyline",
    title: "New York",
    description: "The city that never sleeps"
  }
];

export const countries = [
  "United States",
  "United Kingdom",
  "Germany",
  "France",
  "Canada",
  "Australia",
  "India",
  "China",
  "Dubai, UAE",
  "Japan",
  "Singapore",
  "Switzerland",
  "Thailand",
  "Brazil"
];

export const purposeOptions = [
  "Tourism",
  "Business",
  "Transit",
  "Study",
  "Work",
  "Medical"
];

export const durationOptions = [
  "Less than 30 days",
  "30-90 days",
  "3-6 months",
  "6-12 months",
  "More than 1 year"
];

export const serviceOptions = [
  "Tourist Visa",
  "Business Visa",
  "Student Visa",
  "Express Services",
  "Document Services",
  "General Consultation"
];
