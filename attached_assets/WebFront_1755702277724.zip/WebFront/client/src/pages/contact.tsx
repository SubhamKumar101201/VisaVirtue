import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { MapPin, Phone, Mail, Clock, Send, Navigation, MessageSquare, Calendar, Headset, Globe, Shield } from "lucide-react";
import { insertContactSchema, type InsertContact } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { serviceOptions } from "@/lib/destinations-data";

export default function Contact() {
  const { toast } = useToast();

  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      service: "",
      message: "",
    },
  });

  const submitContactMutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      const response = await apiRequest("POST", "/api/contacts", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Thank you for contacting us. We'll get back to you within 24 hours.",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContact) => {
    submitContactMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="pt-20 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Get In Touch</h1>
            <p className="text-gray-600 text-lg">Visit our Dubai office or contact us for personalized visa assistance</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Send us a Message</h3>
              
              <Card>
                <CardContent className="p-6">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="firstName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>First Name *</FormLabel>
                              <FormControl>
                                <Input placeholder="John" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="lastName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Last Name *</FormLabel>
                              <FormControl>
                                <Input placeholder="Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address *</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="john@example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input type="tel" placeholder="+1 (555) 123-4567" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="service"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Service Interested In</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value || ""}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a service" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {serviceOptions.map((service) => (
                                  <SelectItem key={service} value={service}>
                                    {service}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Message *</FormLabel>
                            <FormControl>
                              <Textarea 
                                rows={5} 
                                placeholder="Tell us about your visa requirements..." 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full bg-visa-gold text-visa-navy px-8 py-4 text-lg font-semibold hover:bg-yellow-500"
                        disabled={submitContactMutation.isPending}
                      >
                        {submitContactMutation.isPending ? (
                          "Sending..."
                        ) : (
                          <>
                            Send Message
                            <Send size={20} className="ml-2" />
                          </>
                        )}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Information & Map */}
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Visit Our Office</h3>
              
              {/* Office Details */}
              <Card className="mb-6">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <MapPin className="text-visa-gold text-lg mt-1" size={20} />
                      <div>
                        <div className="font-semibold text-gray-900">Dubai Office</div>
                        <div className="text-gray-600">Sheikh Zayed Road, Trade Centre<br />Dubai, United Arab Emirates</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Phone className="text-visa-gold text-lg" size={20} />
                      <div>
                        <div className="font-semibold text-gray-900">Phone</div>
                        <div className="text-gray-600">+971 4 123 4567</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Mail className="text-visa-gold text-lg" size={20} />
                      <div>
                        <div className="font-semibold text-gray-900">Email</div>
                        <div className="text-gray-600">info@visavirtue.com</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <Clock className="text-visa-gold text-lg mt-1" size={20} />
                      <div>
                        <div className="font-semibold text-gray-900">Business Hours</div>
                        <div className="text-gray-600">
                          Sunday - Thursday: 9:00 AM - 6:00 PM<br />
                          Friday - Saturday: 10:00 AM - 4:00 PM
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Interactive Map Placeholder */}
              <div className="bg-gray-200 rounded-xl h-80 flex items-center justify-center relative overflow-hidden mb-6">
                <img 
                  src="https://images.unsplash.com/photo-1582672060674-bc2bd808a8b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                  alt="Dubai Office Location" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                  <div className="text-center text-white">
                    <MapPin className="text-4xl text-visa-gold mb-4 mx-auto" size={48} />
                    <div className="font-semibold text-lg">VisaVirtue Dubai Office</div>
                    <div className="text-sm opacity-90">Sheikh Zayed Road, Trade Centre</div>
                    <Button className="mt-4 bg-visa-gold text-visa-navy px-6 py-2 font-semibold hover:bg-yellow-500">
                      <Navigation size={16} className="mr-2" />
                      Get Directions
                    </Button>
                  </div>
                </div>
              </div>

              {/* Quick Contact Options */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button className="flex items-center justify-center space-x-2 bg-green-600 text-white py-3 hover:bg-green-700">
                  <Phone size={16} />
                  <span>Call Now</span>
                </Button>
                <Button className="flex items-center justify-center space-x-2 bg-green-500 text-white py-3 hover:bg-green-600">
                  <MessageSquare size={16} />
                  <span>WhatsApp</span>
                </Button>
                <Button className="flex items-center justify-center space-x-2 bg-visa-navy text-white py-3 hover:bg-blue-800">
                  <Calendar size={16} />
                  <span>Book Appointment</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Support Features */}
          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="p-6">
              <div className="w-16 h-16 bg-visa-gold-light rounded-full flex items-center justify-center mx-auto mb-4">
                <Headset className="text-visa-gold text-2xl" size={32} />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">24/7 Support</h4>
              <p className="text-gray-600">Round-the-clock assistance for all your visa queries and emergencies.</p>
            </div>
            
            <div className="p-6">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="text-visa-navy text-2xl" size={32} />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Global Network</h4>
              <p className="text-gray-600">Extensive network of embassy contacts and local partners worldwide.</p>
            </div>
            
            <div className="p-6">
              <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="text-green-600 text-2xl" size={32} />
              </div>
              <h4 className="font-bold text-gray-900 mb-2">Secure Process</h4>
              <p className="text-gray-600">Your personal information is protected with bank-level security.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
