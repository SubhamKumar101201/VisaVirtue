export interface VisaRequirementResult {
  title: string;
  description: string;
  processingTime: string;
  validity: string;
  entryType: string;
  fee: string;
  documents: string[];
  required: boolean;
}

export const defaultVisaResult: VisaRequirementResult = {
  title: "Visa Required",
  description: "A tourist visa is required for US citizens traveling to Dubai, UAE for tourism purposes.",
  processingTime: "3-5 business days",
  validity: "60 days",
  entryType: "Multiple Entry",
  fee: "$350",
  documents: [
    "Valid passport (minimum 6 months validity)",
    "Recent passport-sized photograph",
    "Completed visa application form",
    "Travel insurance coverage",
    "Bank statements (last 3 months)",
    "Flight itinerary",
    "Hotel booking confirmation"
  ],
  required: true
};
