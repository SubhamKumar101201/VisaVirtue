import { VisaCheckerForm } from "@/components/visa-checker-form";

export default function VisaChecker() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="pt-20">
        <VisaCheckerForm />
      </div>
      
      {/* Additional Information Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-gray-600 text-lg">Get accurate visa requirements in three simple steps</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-visa-gold-light rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-visa-gold">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Select Countries</h3>
              <p className="text-gray-600">Choose your departure and destination countries from our comprehensive list</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-visa-gold-light rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-visa-gold">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Specify Purpose</h3>
              <p className="text-gray-600">Tell us the purpose and duration of your visit for accurate requirements</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-visa-gold-light rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-visa-gold">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Get Results</h3>
              <p className="text-gray-600">Receive detailed visa requirements, processing times, and fees instantly</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
