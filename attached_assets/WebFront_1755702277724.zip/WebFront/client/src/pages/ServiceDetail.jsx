import React from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  CheckCircle, 
  Clock, 
  DollarSign, 
  FileText, 
  Star,
  Users,
  Globe,
  ArrowRight
} from 'lucide-react';

const ServiceDetail = () => {
  const { slug } = useParams();

  // This would normally fetch data based on slug
  const service = {
    title: 'Tourist Visa Service',
    description: 'Complete tourist visa processing with expert guidance and document preparation.',
    longDescription: 'Our tourist visa service is designed to make your leisure travel dreams come true. Whether you\'re planning to visit family, explore new cultures, or simply enjoy a vacation abroad, our experienced team will guide you through every step of the visa application process.',
    basePrice: 99,
    successRate: 98,
    processingTime: {
      standard: '10-15 business days',
      express: '5-7 business days', 
      emergency: '2-3 business days'
    },
    features: [
      'Complete application assistance',
      'Document preparation and review',
      'Interview preparation (if required)',
      'Real-time status tracking',
      '24/7 customer support',
      'Visa rejection protection',
      'Multiple country coverage',
      'Express processing available'
    ],
    requirements: [
      'Valid passport with at least 6 months validity',
      'Recent passport-sized photographs',
      'Proof of travel arrangements (flight bookings)',
      'Hotel reservations or invitation letters',
      'Financial statements and bank documents',
      'Travel insurance (country dependent)',
      'Employment verification letter',
      'Additional documents based on destination'
    ],
    popularCountries: ['USA', 'UK', 'Canada', 'Australia', 'Schengen Area', 'Japan', 'Singapore', 'UAE'],
    testimonials: [
      {
        name: 'Sarah Johnson',
        country: 'United States',
        rating: 5,
        text: 'Excellent service! Got my Schengen visa approved without any hassle.',
        visaType: 'Tourist Visa - Europe'
      },
      {
        name: 'Michael Chen', 
        country: 'Canada',
        rating: 5,
        text: 'Professional team and fast processing. Highly recommended!',
        visaType: 'Tourist Visa - Japan'
      }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              {service.title}
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              {service.description}
            </p>
            <div className="flex items-center justify-center space-x-8">
              <div className="flex items-center space-x-2">
                <Star className="w-5 h-5 text-yellow-400" />
                <span>{service.successRate}% Success Rate</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>From {service.processingTime.express}</span>
              </div>
              <div className="flex items-center space-x-2">
                <DollarSign className="w-5 h-5" />
                <span>Starting at ${service.basePrice}</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            {/* Overview */}
            <motion.section
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white rounded-xl shadow-md p-8"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Service Overview</h2>
              <p className="text-gray-600 leading-relaxed mb-6">
                {service.longDescription}
              </p>
              
              {/* Key Features */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {service.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.section>

            {/* Processing Options */}
            <motion.section
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white rounded-xl shadow-md p-8"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Processing Options</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 border border-gray-200 rounded-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Standard</h3>
                  <p className="text-3xl font-bold text-blue-600 mb-2">${service.basePrice}</p>
                  <p className="text-gray-600 mb-4">{service.processingTime.standard}</p>
                  <p className="text-sm text-gray-500">Most popular option</p>
                </div>
                
                <div className="text-center p-6 border-2 border-blue-600 rounded-lg bg-blue-50">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Express</h3>
                  <p className="text-3xl font-bold text-blue-600 mb-2">${service.basePrice + 50}</p>
                  <p className="text-gray-600 mb-4">{service.processingTime.express}</p>
                  <p className="text-sm text-blue-600 font-medium">Recommended</p>
                </div>
                
                <div className="text-center p-6 border border-gray-200 rounded-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Emergency</h3>
                  <p className="text-3xl font-bold text-blue-600 mb-2">${service.basePrice + 100}</p>
                  <p className="text-gray-600 mb-4">{service.processingTime.emergency}</p>
                  <p className="text-sm text-gray-500">Subject to availability</p>
                </div>
              </div>
            </motion.section>

            {/* Requirements */}
            <motion.section
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-white rounded-xl shadow-md p-8"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Required Documents</h2>
              <div className="space-y-3">
                {service.requirements.map((requirement, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-3 flex-shrink-0"></div>
                    <span className="text-gray-700">{requirement}</span>
                  </div>
                ))}
              </div>
              
              <div className="mt-8 p-6 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-yellow-800">
                  <strong>Note:</strong> Additional documents may be required based on your specific destination 
                  and individual circumstances. Our team will provide a personalized checklist during consultation.
                </p>
              </div>
            </motion.section>

            {/* Testimonials */}
            <motion.section
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="bg-white rounded-xl shadow-md p-8"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Client Testimonials</h2>
              <div className="space-y-6">
                {service.testimonials.map((testimonial, index) => (
                  <div key={index} className="border-l-4 border-blue-600 pl-6">
                    <div className="flex items-center mb-2">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-gray-700 italic mb-2">"{testimonial.text}"</p>
                    <div className="text-sm text-gray-600">
                      <strong>{testimonial.name}</strong> from {testimonial.country}
                      <br />
                      {testimonial.visaType}
                    </div>
                  </div>
                ))}
              </div>
            </motion.section>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-8">
            {/* Quick Application */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl text-white p-6 sticky top-24"
            >
              <h3 className="text-2xl font-bold mb-4">Start Your Application</h3>
              <div className="space-y-4 mb-6">
                <div className="flex items-center justify-between">
                  <span>Success Rate</span>
                  <span className="font-semibold">{service.successRate}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Processing Time</span>
                  <span className="font-semibold">{service.processingTime.express}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Starting Price</span>
                  <span className="font-semibold">${service.basePrice}</span>
                </div>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full py-4 bg-white text-blue-600 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors mb-4"
              >
                Apply Now
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full py-3 bg-transparent border-2 border-white text-white rounded-lg font-medium hover:bg-white hover:text-blue-600 transition-colors"
              >
                Free Consultation
              </motion.button>
            </motion.div>

            {/* Popular Countries */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white rounded-xl shadow-md p-6"
            >
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Popular Destinations</h3>
              <div className="space-y-3">
                {service.popularCountries.map((country, index) => (
                  <div key={index} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                    <span className="text-gray-700">{country}</span>
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Contact Support */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-white rounded-xl shadow-md p-6"
            >
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Need Help?</h3>
              <p className="text-gray-600 mb-6">
                Our visa experts are available 24/7 to answer your questions and provide personalized guidance.
              </p>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Users className="w-5 h-5 text-blue-600" />
                  <span className="text-gray-700">Expert Consultation</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Globe className="w-5 h-5 text-blue-600" />
                  <span className="text-gray-700">24/7 Support</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-blue-600" />
                  <span className="text-gray-700">Success Guarantee</span>
                </div>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full mt-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                Contact Support
              </motion.button>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceDetail;