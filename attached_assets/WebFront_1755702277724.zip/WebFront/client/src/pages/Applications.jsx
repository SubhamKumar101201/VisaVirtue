import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Eye, 
  Download,
  Calendar,
  Globe,
  Filter,
  Search,
  RefreshCw
} from 'lucide-react';

const Applications = () => {
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock applications data
  const applications = [
    {
      id: 'VV-2024-001',
      service: 'Tourist Visa',
      country: 'United Kingdom',
      status: 'approved',
      submittedDate: '2024-01-15',
      completedDate: '2024-01-28',
      amount: '$99',
      documents: 4,
      notes: 'Application approved successfully. Visa valid for 6 months.'
    },
    {
      id: 'VV-2024-002',
      service: 'Business Visa',
      country: 'Singapore',
      status: 'processing',
      submittedDate: '2024-02-01',
      estimatedCompletion: '2024-02-15',
      amount: '$149',
      documents: 5,
      notes: 'Under review by immigration authorities.'
    },
    {
      id: 'VV-2024-003',
      service: 'Student Visa',
      country: 'Canada',
      status: 'approved',
      submittedDate: '2024-01-20',
      completedDate: '2024-02-05',
      amount: '$199',
      documents: 8,
      notes: 'Student visa approved. Valid for duration of studies.'
    },
    {
      id: 'VV-2023-045',
      service: 'Work Permit',
      country: 'Australia',
      status: 'documents-requested',
      submittedDate: '2023-12-10',
      amount: '$299',
      documents: 6,
      notes: 'Additional employment verification required.'
    },
    {
      id: 'VV-2023-032',
      service: 'Tourist Visa',
      country: 'Japan',
      status: 'rejected',
      submittedDate: '2023-11-22',
      completedDate: '2023-12-05',
      amount: '$99',
      documents: 3,
      notes: 'Application rejected due to insufficient financial documentation. You may reapply.'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'text-green-700 bg-green-100 border-green-200';
      case 'processing': return 'text-blue-700 bg-blue-100 border-blue-200';
      case 'documents-requested': return 'text-yellow-700 bg-yellow-100 border-yellow-200';
      case 'rejected': return 'text-red-700 bg-red-100 border-red-200';
      case 'submitted': return 'text-purple-700 bg-purple-100 border-purple-200';
      default: return 'text-gray-700 bg-gray-100 border-gray-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved': return <CheckCircle className="w-4 h-4" />;
      case 'processing': return <Clock className="w-4 h-4" />;
      case 'documents-requested': return <FileText className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      case 'submitted': return <RefreshCw className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const formatStatus = (status) => {
    return status.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  const filteredApplications = applications.filter(app => {
    const matchesStatus = filterStatus === 'all' || app.status === filterStatus;
    const matchesSearch = app.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.service.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.country.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
            My Applications
          </h1>
          <p className="text-lg text-gray-600">
            Track and manage all your visa applications in one place.
          </p>
        </motion.div>

        {/* Filters and Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="bg-white rounded-xl shadow-md p-6 mb-8"
        >
          <div className="flex flex-col md:flex-row gap-4 items-center">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search applications..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              />
            </div>

            {/* Status Filter */}
            <div className="flex items-center space-x-2">
              <Filter className="text-gray-400 w-5 h-5" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              >
                <option value="all">All Status</option>
                <option value="submitted">Submitted</option>
                <option value="processing">Processing</option>
                <option value="documents-requested">Documents Requested</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Applications List */}
        <div className="space-y-6">
          {filteredApplications.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-center py-12"
            >
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No applications found</h3>
              <p className="text-gray-500">Try adjusting your filters or search terms.</p>
            </motion.div>
          ) : (
            filteredApplications.map((application, index) => (
              <motion.div
                key={application.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
              >
                <div className="p-6">
                  {/* Application Header */}
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
                    <div className="flex items-center space-x-4 mb-4 md:mb-0">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Globe className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900">
                          {application.service} - {application.country}
                        </h3>
                        <p className="text-gray-600">Application ID: {application.id}</p>
                      </div>
                    </div>

                    <div className={`inline-flex items-center space-x-2 px-3 py-2 rounded-lg border ${getStatusColor(application.status)}`}>
                      {getStatusIcon(application.status)}
                      <span className="font-medium">{formatStatus(application.status)}</span>
                    </div>
                  </div>

                  {/* Application Details */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600 mb-1">
                        <Calendar className="w-4 h-4" />
                        <span>Submitted</span>
                      </div>
                      <p className="font-medium text-gray-900">
                        {new Date(application.submittedDate).toLocaleDateString()}
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600 mb-1">
                        <Clock className="w-4 h-4" />
                        <span>{application.completedDate ? 'Completed' : 'Expected'}</span>
                      </div>
                      <p className="font-medium text-gray-900">
                        {application.completedDate 
                          ? new Date(application.completedDate).toLocaleDateString()
                          : application.estimatedCompletion 
                            ? new Date(application.estimatedCompletion).toLocaleDateString()
                            : 'TBD'
                        }
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600 mb-1">
                        <FileText className="w-4 h-4" />
                        <span>Amount</span>
                      </div>
                      <p className="font-medium text-gray-900">{application.amount}</p>
                    </div>
                  </div>

                  {/* Notes */}
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <h4 className="font-medium text-gray-900 mb-2">Latest Update</h4>
                    <p className="text-gray-700">{application.notes}</p>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-3">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                      <span>View Details</span>
                    </motion.button>

                    {application.status === 'approved' && (
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download Visa</span>
                      </motion.button>
                    )}

                    {application.status === 'documents-requested' && (
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center space-x-2 px-4 py-2 bg-yellow-600 text-white rounded-lg font-medium hover:bg-yellow-700 transition-colors"
                      >
                        <FileText className="w-4 h-4" />
                        <span>Upload Documents</span>
                      </motion.button>
                    )}

                    {application.status === 'rejected' && (
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors"
                      >
                        <RefreshCw className="w-4 h-4" />
                        <span>Reapply</span>
                      </motion.button>
                    )}

                    <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                      Contact Support
                    </button>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>

        {/* Summary Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          {[
            { label: 'Total Applications', value: applications.length, color: 'blue' },
            { label: 'Approved', value: applications.filter(app => app.status === 'approved').length, color: 'green' },
            { label: 'In Progress', value: applications.filter(app => ['processing', 'submitted', 'documents-requested'].includes(app.status)).length, color: 'yellow' },
            { label: 'Success Rate', value: `${Math.round((applications.filter(app => app.status === 'approved').length / applications.length) * 100)}%`, color: 'purple' }
          ].map((stat) => (
            <div key={stat.label} className="bg-white rounded-xl shadow-md p-6 text-center">
              <p className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</p>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default Applications;