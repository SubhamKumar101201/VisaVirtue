import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface TestimonialCardProps {
  testimonial: {
    id: number;
    name: string;
    location: string;
    content: string;
    rating: number;
    avatar: string;
  };
}

export function TestimonialCard({ testimonial }: TestimonialCardProps) {
  return (
    <Card className="h-full hover:shadow-xl transition-all duration-300">
      <CardContent className="p-8">
        <div className="flex items-center mb-4">
          <div className="flex text-visa-gold">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={16} className={i < testimonial.rating ? "fill-current" : ""} />
            ))}
          </div>
          <span className="ml-2 text-gray-600 text-sm">{testimonial.rating}.0</span>
        </div>
        <blockquote className="text-gray-700 mb-6 italic">
          "{testimonial.content}"
        </blockquote>
        <div className="flex items-center">
          <img 
            src={testimonial.avatar} 
            alt={testimonial.name} 
            className="w-12 h-12 rounded-full mr-4 object-cover" 
          />
          <div>
            <div className="font-semibold text-gray-900">{testimonial.name}</div>
            <div className="text-gray-500 text-sm">{testimonial.location}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
