import { useQuery } from "@tanstack/react-query";
import { HeroCarousel } from "@/components/hero-carousel";
import { VisaCheckerForm } from "@/components/visa-checker-form";
import { TestimonialCard } from "@/components/testimonial-card";
import { DestinationCard } from "@/components/destination-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Award, Globe, Clock, IdCard, Bus, FileText, GraduationCap, Headphones, Star } from "lucide-react";
import { Link } from "wouter";
import type { Destination } from "@shared/schema";

export default function Home() {
  const { data: destinations = [] } = useQuery<Destination[]>({
    queryKey: ['/api/destinations'],
  });

  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      location: "New York, USA",
      content: "VisaVirtue made my Dubai visa application incredibly smooth. The team was professional, responsive, and got my visa approved in just 3 days. Highly recommended!",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"
    },
    {
      id: 2,
      name: "Michael Chen",
      location: "Toronto, Canada",
      content: "Outstanding service! The visa checker tool was accurate, and the document guidance was comprehensive. My family's UK visa application was hassle-free.",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      location: "London, UK",
      content: "The express service saved my business trip! When I needed a last-minute visa for Singapore, VisaVirtue processed it in 24 hours. Exceptional service!",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=64&h=64"
    }
  ];

  const services = [
    {
      icon: <IdCard className="text-2xl" />,
      title: "Visa Processing",
      description: "Complete visa application processing with expert guidance and document verification.",
      features: ["Document review", "Application submission", "Status tracking", "Express processing"],
      bgColor: "bg-amber-50",
      iconColor: "text-visa-gold"
    },
    {
      icon: <Bus className="text-2xl" />,
      title: "Business Visas",
      description: "Specialized business visa services for corporate travelers and entrepreneurs.",
      features: ["Corporate packages", "Invitation letters", "Priority processing", "24/7 support"],
      bgColor: "bg-blue-50",
      iconColor: "text-visa-navy"
    },
    {
      icon: <FileText className="text-2xl" />,
      title: "Document Services",
      description: "Professional document preparation, translation, and authentication services.",
      features: ["Document translation", "Apostille services", "Notarization", "Authentication"],
      bgColor: "bg-green-50",
      iconColor: "text-green-600"
    },
    {
      icon: <GraduationCap className="text-2xl" />,
      title: "Student Visas",
      description: "Complete guidance for students seeking education abroad with visa support.",
      features: ["University liaison", "Financial documentation", "Interview preparation", "Post-arrival support"],
      bgColor: "bg-purple-50",
      iconColor: "text-purple-600"
    },
    {
      icon: <Clock className="text-2xl" />,
      title: "Express Services",
      description: "Urgent visa processing for last-minute travel requirements and emergencies.",
      features: ["Same-day processing", "Emergency appointments", "Expedited delivery", "Premium support"],
      bgColor: "bg-red-50",
      iconColor: "text-red-600"
    },
    {
      icon: <Headphones className="text-2xl" />,
      title: "Consultation",
      description: "Expert consultation services to guide you through complex visa requirements.",
      features: ["One-on-one consultation", "Requirement analysis", "Custom solutions", "Follow-up support"],
      bgColor: "bg-indigo-50",
      iconColor: "text-indigo-600"
    }
  ];

  const handleViewDestination = (id: string) => {
    // Navigate to destination details
    console.log('View destination:', id);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Carousel */}
      <HeroCarousel />

      {/* Trust Indicators */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Trusted by Thousands Worldwide</h2>
            <p className="text-gray-600 text-lg">Your visa application is in safe hands with our certified expertise</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center opacity-60 mb-16">
            <div className="flex flex-col items-center space-y-2">
              <Shield className="text-4xl text-visa-navy" size={48} />
              <span className="text-sm font-medium text-gray-700">SSL Secured</span>
            </div>
            <div className="flex flex-col items-center space-y-2">
              <Award className="text-4xl text-visa-gold" size={48} />
              <span className="text-sm font-medium text-gray-700">Certified Agents</span>
            </div>
            <div className="flex flex-col items-center space-y-2">
              <Globe className="text-4xl text-visa-navy" size={48} />
              <span className="text-sm font-medium text-gray-700">Global Network</span>
            </div>
            <div className="flex flex-col items-center space-y-2">
              <Clock className="text-4xl text-visa-gold" size={48} />
              <span className="text-sm font-medium text-gray-700">24/7 Support</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="bg-gray-50 p-8 rounded-xl">
              <div className="text-4xl font-bold text-visa-navy mb-2">50,000+</div>
              <div className="text-gray-600">Successful Applications</div>
            </div>
            <div className="bg-gray-50 p-8 rounded-xl">
              <div className="text-4xl font-bold text-visa-navy mb-2">195</div>
              <div className="text-gray-600">Countries Covered</div>
            </div>
            <div className="bg-gray-50 p-8 rounded-xl">
              <div className="text-4xl font-bold text-visa-navy mb-2">99.2%</div>
              <div className="text-gray-600">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Visa Checker */}
      <VisaCheckerForm />

      {/* Services Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Premium Services</h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto">
              From visa consultation to document processing, we provide end-to-end solutions for all your travel documentation needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="border border-gray-200 hover:shadow-xl transition-all duration-300 hover:transform hover:-translate-y-2">
                <CardContent className="p-8">
                  <div className={`w-16 h-16 ${service.bgColor} rounded-lg flex items-center justify-center mb-6`}>
                    <div className={service.iconColor}>{service.icon}</div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <ul className="text-sm text-gray-500 space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button variant="link" className="text-visa-navy hover:text-visa-blue p-0">
                    Learn More →
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Destinations */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Popular Destinations</h2>
            <p className="text-gray-600 text-lg">
              Discover visa requirements and travel information for top destinations worldwide
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {destinations.slice(0, 4).map((destination) => (
              <DestinationCard 
                key={destination.id} 
                destination={destination} 
                onViewDetails={handleViewDestination}
              />
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/destinations">
              <Button className="bg-visa-gold text-visa-navy px-8 py-3 font-semibold hover:bg-yellow-500">
                View All Destinations →
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
            <p className="text-gray-600 text-lg">Success stories from thousands of satisfied travelers worldwide</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>

          {/* Overall Rating */}
          <div className="mt-16 text-center">
            <Card className="inline-flex items-center space-x-4 px-8 py-6 shadow-lg">
              <CardContent className="p-0 flex items-center space-x-4">
                <div>
                  <div className="text-3xl font-bold text-visa-navy">4.9</div>
                  <div className="flex text-visa-gold justify-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={16} className="fill-current" />
                    ))}
                  </div>
                </div>
                <div className="text-left">
                  <div className="text-lg font-semibold text-gray-900">Excellent Service</div>
                  <div className="text-gray-600">Based on 2,847 reviews</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
