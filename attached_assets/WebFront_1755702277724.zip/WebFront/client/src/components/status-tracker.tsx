import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { CheckCircle, Clock, Eye, Headphones, Download, Bell } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import type { Application } from "@shared/schema";

export function StatusTracker() {
  const [applicationNumber, setApplicationNumber] = useState("");
  const [searchTriggered, setSearchTriggered] = useState(false);
  const { lastMessage, subscribe } = useWebSocket();

  const { data: application, isLoading } = useQuery<Application>({
    queryKey: ['/api/applications/number', applicationNumber],
    enabled: searchTriggered && Boolean(applicationNumber),
  });

  useEffect(() => {
    if (application) {
      subscribe(application.id);
    }
  }, [application, subscribe]);

  useEffect(() => {
    if (lastMessage && lastMessage.type === 'statusUpdate') {
      // Handle real-time status updates
      console.log('Status update received:', lastMessage);
    }
  }, [lastMessage]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (applicationNumber.trim()) {
      setSearchTriggered(true);
    }
  };

  const statusSteps = [
    {
      id: 1,
      title: "Application Submitted",
      description: "Your application has been received and is in our system.",
      timestamp: "Jan 15, 2024 - 10:30 AM",
      status: "completed"
    },
    {
      id: 2,
      title: "Documents Verified",
      description: "All required documents have been verified and accepted.",
      timestamp: "Jan 15, 2024 - 2:45 PM",
      status: "completed"
    },
    {
      id: 3,
      title: "Under Review",
      description: "Your application is currently being reviewed by our visa specialists.",
      timestamp: "In Progress",
      status: "current",
      progress: 60
    },
    {
      id: 4,
      title: "Embassy Processing",
      description: "Your application will be submitted to the embassy for final processing.",
      timestamp: "Pending",
      status: "pending"
    },
    {
      id: 5,
      title: "Visa Ready",
      description: "Your visa will be ready for collection or delivery.",
      timestamp: "Pending",
      status: "pending"
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="text-white" size={20} />;
      case 'current':
        return <div className="w-2 h-2 bg-white rounded-full animate-pulse" />;
      default:
        return <div className="w-2 h-2 bg-white rounded-full" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-600';
      case 'current':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-300';
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Track Your Application</h2>
          <p className="text-gray-600 text-lg">Monitor your visa application status in real-time</p>
        </div>

        {/* Search Form */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <form onSubmit={handleSearch} className="flex gap-4">
              <Input
                type="text"
                placeholder="Enter your application number (e.g., VV-2024-001234)"
                value={applicationNumber}
                onChange={(e) => setApplicationNumber(e.target.value)}
                className="flex-1"
              />
              <Button 
                type="submit" 
                className="bg-visa-navy text-white hover:bg-blue-800"
                disabled={isLoading}
              >
                {isLoading ? "Searching..." : "Track Application"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {application && (
          <Card className="border border-gray-200 shadow-lg">
            <CardContent className="p-8">
              {/* Application Status Header */}
              <div className="flex items-center justify-between mb-8 pb-6 border-b border-gray-200">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Application #{application.applicationNumber}</h3>
                  <p className="text-gray-600">{application.purpose} Visa - {application.toCountry}</p>
                </div>
                <div className="text-right">
                  <div className="inline-flex items-center px-4 py-2 bg-yellow-100 text-yellow-800 rounded-full text-sm font-medium">
                    <Clock size={16} className="mr-2" />
                    {application.status}
                  </div>
                  <p className="text-sm text-gray-500 mt-1">Estimated completion: 2 days</p>
                </div>
              </div>

              {/* Progress Timeline */}
              <div className="relative">
                <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-300"></div>
                
                <div className="space-y-8">
                  {statusSteps.map((step) => (
                    <div key={step.id} className="relative flex items-start space-x-4">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 z-10 ${getStatusColor(step.status)}`}>
                        {getStatusIcon(step.status)}
                      </div>
                      <div className="flex-1 pb-8">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold text-gray-900">{step.title}</h4>
                          <span className="text-sm text-gray-500">{step.timestamp}</span>
                        </div>
                        <p className="text-gray-600 text-sm mt-1">{step.description}</p>
                        {step.status === 'current' && step.progress && (
                          <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-yellow-500 h-2 rounded-full transition-all duration-500" 
                              style={{ width: `${step.progress}%` }}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 mt-8 pt-6 border-t border-gray-200">
                <Button className="flex-1 bg-visa-navy text-white hover:bg-blue-800">
                  <Eye size={16} className="mr-2" />
                  View Full Details
                </Button>
                <Button variant="outline" className="flex-1 border-visa-navy text-visa-navy hover:bg-visa-navy hover:text-white">
                  <Headphones size={16} className="mr-2" />
                  Contact Support
                </Button>
                <Button variant="outline" className="flex-1 bg-gray-100 text-gray-700 hover:bg-gray-200">
                  <Download size={16} className="mr-2" />
                  Download Receipt
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {searchTriggered && !application && !isLoading && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-6 text-center">
              <p className="text-red-700">No application found with this number. Please check and try again.</p>
            </CardContent>
          </Card>
        )}

        {/* Notifications */}
        {application && (
          <Card className="mt-8 bg-blue-50 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-start space-x-3">
                <Bell className="text-visa-blue mt-1" size={20} />
                <div>
                  <h4 className="font-semibold text-visa-navy mb-2">Stay Updated</h4>
                  <p className="text-visa-navy text-sm mb-3">Get instant notifications about your application status via email and SMS.</p>
                  <div className="flex items-center space-x-4">
                    <label className="flex items-center">
                      <input type="checkbox" defaultChecked className="mr-2" />
                      <span className="text-sm">Email Notifications</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" defaultChecked className="mr-2" />
                      <span className="text-sm">SMS Updates</span>
                    </label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  );
}
