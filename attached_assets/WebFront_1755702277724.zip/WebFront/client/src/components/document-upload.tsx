import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, FileText, CheckCircle, Trash2, Download, Info } from "lucide-react";

interface UploadedFile {
  id: string;
  name: string;
  size: string;
  type: string;
  status: 'uploading' | 'completed' | 'error';
}

export function DocumentUpload() {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([
    {
      id: '1',
      name: 'passport_scan.pdf',
      size: '2.3 MB',
      type: 'pdf',
      status: 'completed'
    },
    {
      id: '2',
      name: 'photo_id.jpg',
      size: '1.8 MB',
      type: 'image',
      status: 'uploading'
    }
  ]);

  const documentChecklist = [
    { id: 1, name: "Passport Copy", description: "Clear scan of bio-data page", status: "completed" },
    { id: 2, name: "Passport Photo", description: "Recent color photograph (35mm x 45mm)", status: "pending" },
    { id: 3, name: "Travel Insurance", description: "Coverage of minimum $100,000", status: "not-started" },
    { id: 4, name: "Bank Statements", description: "Last 3 months' statements", status: "not-started" },
    { id: 5, name: "Flight Itinerary", description: "Round-trip booking confirmation", status: "not-started" },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="text-green-600" size={20} />;
      case 'pending':
        return <div className="w-5 h-5 border-2 border-yellow-500 border-t-transparent rounded-full animate-spin" />;
      default:
        return <div className="w-5 h-5 rounded-full border-2 border-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-50 border-green-200';
      case 'pending':
        return 'bg-yellow-50 border-yellow-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  const handleFileUpload = () => {
    // File upload functionality would be implemented here
    console.log("File upload triggered");
  };

  const removeFile = (id: string) => {
    setUploadedFiles(files => files.filter(file => file.id !== id));
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Document Upload Center</h2>
          <p className="text-gray-600 text-lg">Securely upload your documents for processing</p>
        </div>

        <Card className="shadow-xl">
          <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Upload Area */}
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-6">Upload Documents</h3>
                
                <div 
                  className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-visa-blue transition-colors cursor-pointer"
                  onClick={handleFileUpload}
                >
                  <Upload className="text-4xl text-gray-400 mb-4 mx-auto" size={48} />
                  <p className="text-gray-600 mb-4">Drag and drop files here or click to browse</p>
                  <Button onClick={handleFileUpload} className="bg-visa-navy text-white hover:bg-blue-800">
                    Choose Files
                  </Button>
                  <p className="text-xs text-gray-500 mt-2">Supported formats: PDF, JPG, PNG (Max: 10MB each)</p>
                </div>

                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Recently Uploaded</h4>
                  <div className="space-y-2">
                    {uploadedFiles.map((file) => (
                      <div key={file.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <FileText className={file.type === 'pdf' ? "text-red-600" : "text-blue-600"} size={20} />
                          <div>
                            <div className="font-medium text-sm">{file.name}</div>
                            <div className="text-xs text-gray-500">{file.size}</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {file.status === 'completed' ? (
                            <CheckCircle className="text-green-600" size={20} />
                          ) : file.status === 'uploading' ? (
                            <div className="w-4 h-4 border-2 border-visa-blue border-t-transparent rounded-full animate-spin" />
                          ) : null}
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => removeFile(file.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Document Checklist */}
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-6">Document Checklist</h3>
                
                <div className="space-y-4">
                  {documentChecklist.map((doc) => (
                    <div key={doc.id} className={`flex items-start space-x-3 p-4 border rounded-lg ${getStatusColor(doc.status)}`}>
                      {getStatusIcon(doc.status)}
                      <div>
                        <div className={`font-semibold ${
                          doc.status === 'completed' ? 'text-green-800' : 
                          doc.status === 'pending' ? 'text-yellow-800' : 'text-gray-700'
                        }`}>
                          {doc.name}
                        </div>
                        <div className={`text-sm ${
                          doc.status === 'completed' ? 'text-green-700' : 
                          doc.status === 'pending' ? 'text-yellow-700' : 'text-gray-600'
                        }`}>
                          {doc.description}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Info className="text-visa-blue" size={20} />
                    <span className="font-semibold text-visa-navy">Quick Tip</span>
                  </div>
                  <p className="text-sm text-visa-navy">
                    Ensure all documents are clear, recent, and in the correct format for faster processing.
                  </p>
                </div>

                <Button 
                  variant="outline" 
                  className="w-full mt-4 border-visa-navy text-visa-navy hover:bg-visa-navy hover:text-white"
                >
                  <Download size={16} className="mr-2" />
                  Download PDF Checklist
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
