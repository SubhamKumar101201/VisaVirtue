import { StatusTracker } from "@/components/status-tracker";

export default function TrackStatus() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="pt-20">
        <StatusTracker />
      </div>
    </div>
  );
}
