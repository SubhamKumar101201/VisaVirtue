import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Plane, 
  Briefcase, 
  GraduationCap, 
  FileText, 
  Clock, 
  Shield, 
  Users,
  CheckCircle,
  ArrowRight,
  Star
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      slug: 'tourist-visa',
      icon: Plane,
      title: 'Tourist Visa',
      shortDescription: 'Explore the world with hassle-free tourist visa processing',
      fullDescription: 'Perfect for leisure travel, sightseeing, and visiting friends or family abroad. Our expert team ensures your tourist visa application is processed efficiently with all required documentation.',
      basePrice: 99,
      processingTime: {
        standard: '10-15 business days',
        express: '5-7 business days',
        emergency: '2-3 business days'
      },
      features: [
        'Complete application assistance',
        'Document preparation guidance',
        'Interview preparation (if required)',
        'Real-time status tracking',
        '24/7 customer support',
        'Visa rejection protection'
      ],
      popularCountries: ['USA', 'UK', 'Canada', 'Australia', 'Schengen Area', 'Japan'],
      successRate: 98,
      category: 'Visa Services'
    },
    {
      slug: 'business-visa',
      icon: Briefcase,
      title: 'Business Visa',
      shortDescription: 'Expand your business globally with our corporate visa solutions',
      fullDescription: 'Ideal for business meetings, conferences, trade shows, and exploring international business opportunities. We provide comprehensive support for corporate travelers.',
      basePrice: 149,
      processingTime: {
        standard: '7-12 business days',
        express: '4-6 business days',
        emergency: '1-2 business days'
      },
      features: [
        'Corporate account management',
        'Business invitation letters',
        'Multi-entry visa support',
        'Priority processing',
        'Dedicated account manager',
        'Group application discounts'
      ],
      popularCountries: ['China', 'India', 'UAE', 'Singapore', 'Germany', 'Brazil'],
      successRate: 96,
      category: 'Visa Services'
    },
    {
      slug: 'student-visa',
      icon: GraduationCap,
      title: 'Student Visa',
      shortDescription: 'Pursue your educational dreams with comprehensive student visa support',
      fullDescription: 'Complete assistance for students planning to study abroad. From university applications to visa approval, we guide you through every step of your educational journey.',
      basePrice: 199,
      processingTime: {
        standard: '15-20 business days',
        express: '8-12 business days',
        emergency: '4-6 business days'
      },
      features: [
        'University partnership network',
        'Scholarship guidance',
        'Financial documentation help',
        'Accommodation assistance',
        'Post-arrival support services',
        'Dependent visa support'
      ],
      popularCountries: ['USA', 'UK', 'Canada', 'Australia', 'Germany', 'Netherlands'],
      successRate: 94,
      category: 'Visa Services'
    },
    {
      slug: 'work-permit',
      icon: FileText,
      title: 'Work Permit & Employment Visa',
      shortDescription: 'Launch your international career with work permit assistance',
      fullDescription: 'Comprehensive support for skilled professionals seeking employment abroad. We help with work permits, employment visas, and permanent residency applications.',
      basePrice: 299,
      processingTime: {
        standard: '20-30 business days',
        express: '12-18 business days',
        emergency: '7-10 business days'
      },
      features: [
        'Job market insights',
        'Skills assessment support',
        'Employer sponsorship guidance',
        'Family visa coordination',
        'Permanent residency pathway',
        'Tax and legal compliance'
      ],
      popularCountries: ['Canada', 'Australia', 'UAE', 'Singapore', 'Germany', 'New Zealand'],
      successRate: 92,
      category: 'Visa Services'
    },
    {
      slug: 'document-services',
      icon: Shield,
      title: 'Document Services',
      shortDescription: 'Professional document preparation and authentication services',
      fullDescription: 'Complete document services including attestation, apostille, translation, and notarization. We ensure all your documents meet international standards.',
      basePrice: 79,
      processingTime: {
        standard: '5-7 business days',
        express: '2-3 business days',
        emergency: '24-48 hours'
      },
      features: [
        'Document authentication',
        'Apostille services',
        'Certified translations',
        'Notarization services',
        'Digital document storage',
        'Express courier services'
      ],
      popularCountries: ['All Countries'],
      successRate: 100,
      category: 'Document Services'
    },
    {
      slug: 'consultation',
      icon: Users,
      title: 'Expert Consultation',
      shortDescription: 'Personalized immigration and visa consultation services',
      fullDescription: 'One-on-one consultation with our certified immigration experts. Get personalized advice for your unique situation and immigration goals.',
      basePrice: 129,
      processingTime: {
        standard: 'Same day booking',
        express: 'Within 2 hours',
        emergency: 'Immediate (subject to availability)'
      },
      features: [
        'Certified immigration consultants',
        'Personalized immigration strategy',
        'Document checklist creation',
        'Application timeline planning',
        'Follow-up support sessions',
        'Written consultation report'
      ],
      popularCountries: ['All Countries'],
      successRate: 100,
      category: 'Consultation'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Our Premium Services
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              Comprehensive visa and immigration services tailored to your specific needs. 
              From tourist visas to permanent residency, we've got you covered.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.slug}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group"
              >
                <div className="p-8">
                  {/* Service Icon and Category */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <service.icon size={32} className="text-white" />
                    </div>
                    <span className="text-sm text-blue-600 bg-blue-50 px-3 py-1 rounded-full font-medium">
                      {service.category}
                    </span>
                  </div>

                  {/* Service Title and Description */}
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    {service.title}
                  </h3>
                  
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {service.shortDescription}
                  </p>

                  {/* Success Rate */}
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    </div>
                    <span className="text-sm text-gray-600">
                      {service.successRate}% Success Rate
                    </span>
                  </div>

                  {/* Key Features */}
                  <div className="space-y-2 mb-6">
                    {service.features.slice(0, 3).map((feature, idx) => (
                      <div key={idx} className="flex items-center space-x-2">
                        <CheckCircle size={16} className="text-green-500" />
                        <span className="text-sm text-gray-600">{feature}</span>
                      </div>
                    ))}
                    {service.features.length > 3 && (
                      <div className="text-sm text-blue-600 font-medium">
                        +{service.features.length - 3} more features
                      </div>
                    )}
                  </div>

                  {/* Processing Time */}
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock size={16} className="text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">Processing Time</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      Standard: {service.processingTime.standard}
                    </div>
                  </div>

                  {/* Price and CTA */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-3xl font-bold text-blue-600">
                        ${service.basePrice}
                      </span>
                      <span className="text-gray-500 text-sm">+ govt. fees</span>
                    </div>
                    
                    <Link to={`/services/${service.slug}`}>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                      >
                        <span>Learn More</span>
                        <ArrowRight size={16} />
                      </motion.button>
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose VisaVirtue?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We combine expertise, technology, and personalized service to deliver the best visa experience
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Shield,
                title: '100% Secure',
                description: 'Your data is protected with bank-level security measures'
              },
              {
                icon: Clock,
                title: 'Fast Processing',
                description: 'Express services available for urgent applications'
              },
              {
                icon: Users,
                title: 'Expert Team',
                description: 'Certified immigration consultants with years of experience'
              },
              {
                icon: CheckCircle,
                title: 'High Success Rate',
                description: 'Over 95% application approval rate across all services'
              }
            ].map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <benefit.icon size={32} className="text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {benefit.title}
                </h3>
                <p className="text-gray-600">
                  {benefit.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold mb-6">
              Ready to Start Your Application?
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Get a free consultation and let our experts guide you through the visa process
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contact">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white text-blue-600 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-200"
                >
                  Get Free Consultation
                </motion.button>
              </Link>
              <Link to="/visa-checker">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-transparent border-2 border-white text-white rounded-xl font-semibold text-lg hover:bg-white hover:text-blue-600 transition-all duration-200"
                >
                  Check Requirements
                </motion.button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Services;