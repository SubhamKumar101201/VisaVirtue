import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Destination } from "@shared/schema";

interface DestinationCardProps {
  destination: Destination;
  onViewDetails: (id: string) => void;
}

export function DestinationCard({ destination, onViewDetails }: DestinationCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 hover:transform hover:-translate-y-2">
      <img
        src={destination.imageUrl}
        alt={`${destination.name}, ${destination.country}`}
        className="w-full h-48 object-cover"
      />
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{destination.name}, {destination.country}</h3>
        <p className="text-gray-600 text-sm mb-4">{destination.description}</p>
        
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Visa Required:</span>
            <span className={`font-medium ${
              destination.visaRequired === "Yes" ? "text-red-600" : 
              destination.visaRequired === "No" ? "text-green-600" : "text-yellow-600"
            }`}>
              {destination.visaRequired}
            </span>
          </div>
          {destination.processingTime && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Processing:</span>
              <span>{destination.processingTime}</span>
            </div>
          )}
          {destination.priceFrom && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">From:</span>
              <span className="font-semibold text-visa-gold">{destination.priceFrom}</span>
            </div>
          )}
        </div>
        
        <Button 
          onClick={() => onViewDetails(destination.id)} 
          className="w-full bg-visa-navy text-white hover:bg-blue-800 text-sm font-medium"
        >
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}
