const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
  applicationNumber: {
    type: String,
    required: true,
    unique: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  service: {
    type: String,
    required: true,
    enum: [
      'Tourist Visa',
      'Business Visa', 
      'Student Visa',
      'Work Permit',
      'Permanent Residency',
      'Visa Form Filling',
      'Early Appointment Booking',
      'Document Services'
    ]
  },
  fromCountry: {
    type: String,
    required: true
  },
  toCountry: {
    type: String,
    required: true
  },
  purpose: {
    type: String,
    required: true,
    enum: ['Tourism', 'Business', 'Study', 'Work', 'Medical', 'Transit']
  },
  travelDate: {
    type: Date
  },
  returnDate: {
    type: Date
  },
  urgency: {
    type: String,
    enum: ['Standard', 'Express', 'Emergency'],
    default: 'Standard'
  },
  status: {
    type: String,
    enum: ['submitted', 'under-review', 'documents-requested', 'processing', 'approved', 'rejected'],
    default: 'submitted'
  },
  personalInfo: {
    fullName: String,
    dateOfBirth: Date,
    nationality: String,
    passportNumber: String,
    passportExpiry: Date,
    address: String,
    phone: String,
    email: String
  },
  documents: [{
    name: String,
    url: String,
    type: String,
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'refunded'],
    default: 'pending'
  },
  amount: {
    type: Number,
    required: true
  },
  notes: [{
    message: String,
    addedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    addedAt: {
      type: Date,
      default: Date.now
    }
  }],
  estimatedCompletionDate: Date,
  completedAt: Date
}, {
  timestamps: true
});

// Generate application number
applicationSchema.pre('save', function(next) {
  if (!this.applicationNumber) {
    const year = new Date().getFullYear();
    const random = Math.floor(Math.random() * 1000000);
    this.applicationNumber = `VV-${year}-${random}`;
  }
  next();
});

module.exports = mongoose.model('Application', applicationSchema);